<!DOCTYPE html>
<html>
<head>
	<title>Adivina</title>
</head>
<body>


	<?php

	define("MinNum","1");

	define("MaxNum","50");

	

	$intentos=6;

	/*style="visibility: hidden;" */
	?>

	<h2>Adivina el numero entre <?php 	echo MinNum." y " . MaxNum;?></h2>

	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

		<?php define("numeroAlearotio", rand (MinNum ,MaxNum)); ?>

		<input type="number" name="a" min="1" max="50" value="<?php echo numeroAlearotio;?>"><br>

		<input type="number" name="quantity" min="1" max="50"><br>

		<input type="submit" name="submit" value="Submit Form"><br>

	</form>


	<br>

	<?php 


	//echo numeroAlearotio . "<br>";

	echo numeroAlearotio . "<br>";

	if(isset($_POST['submit'])){

		$numero=$_POST["quantity"];

		$intentos=$_POST["a"];

		if (numeroAlearotio==$numero) {

			echo "Lo has adivinado el numero aleatorio es <br>";

		}elseif (numeroAlearotio>$numero) {

			echo "El numero es bajo<br>";

		}elseif (numeroAlearotio<$numero) {

			echo "Numero introduciso mayor al aleatorio<br>";

		}


		if ($intentos==0) {
			echo "Has perdido<br>";
		}
		
	}

	?>

</body>
</html>